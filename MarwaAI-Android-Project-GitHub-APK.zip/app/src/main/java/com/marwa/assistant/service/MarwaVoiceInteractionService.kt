package com.marwa.assistant.service

import android.app.VoiceInteractionSession
import android.content.Context
import android.os.Bundle
import android.service.voice.AlwaysOnHotwordDetector
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSessionService
import android.util.Log
import java.util.Locale

class MarwaVoiceInteractionService : VoiceInteractionService() {

    private var hotwordDetector: AlwaysOnHotwordDetector? = null

    override fun onReady() {
        super.onReady()
        Log.i("MarwaVoice", "Marwa VoiceInteractionService ready as primary assistant.")
        
        hotwordDetector = createAlwaysOnHotwordDetector(
            "Hey Marwa",
            Locale("ur", "PK"),
            object : AlwaysOnHotwordDetector.Callback() {
                override fun onAvailabilityChanged(status: Int) {}
                override fun onDetected(eventPayload: AlwaysOnHotwordDetector.EventPayload?) {
                    showSession(Bundle().apply { putBoolean("HOTWORD_TRIGGERED", true) }, 0)
                }
                override fun onError() {}
                override fun onRecognitionPaused() {}
                override fun onRecognitionResumed() {}
            }
        )
    }
}

class MarwaVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return MarwaVoiceSession(this)
    }
}

class MarwaVoiceSession(context: Context) : VoiceInteractionSession(context) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i("MarwaVoice", "Voice session plate opened.")
    }
}
