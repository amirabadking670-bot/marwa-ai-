package com.marwa.assistant.service

import android.content.Intent
import android.speech.RecognitionService
import android.util.Log

class MarwaRecognitionService : RecognitionService() {

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        Log.i("MarwaRecognition", "Recognition started")
    }

    override fun onCancel(listener: Callback?) {
        Log.i("MarwaRecognition", "Recognition cancelled")
    }

    override fun onStopListening(listener: Callback?) {
        Log.i("MarwaRecognition", "Recognition stopped")
    }
}
