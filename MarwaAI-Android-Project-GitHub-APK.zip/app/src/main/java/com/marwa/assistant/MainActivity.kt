package com.marwa.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.marwa.assistant.automation.AppIntentDispatcher
import com.marwa.assistant.network.GeminiClient
import com.marwa.assistant.service.MarwaAccessibilityService
import com.marwa.assistant.ui.theme.MarwaAITheme
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Microphone permission is required for voice control", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        textToSpeech = TextToSpeech(this, this)
        initSpeechRecognizer()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            MarwaAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AssistantScreen(
                        isAccessibilityEnabled = isAccessibilityServiceEnabled(),
                        onOpenAccessibilitySettings = { openAccessibilitySettings() },
                        onStartListening = { startVoiceInput() },
                        onStopListening = { stopVoiceInput() },
                        onSpeak = { text, lang -> speakText(text, lang) }
                    )
                }
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {}
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        matches?.firstOrNull()?.let { spokenQuery ->
                            handleSpokenCommand(spokenQuery)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("ur-PK", "en-US", "hi-IN"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun stopVoiceInput() {
        speechRecognizer?.stopListening()
    }

    private fun handleSpokenCommand(query: String) {
        val lower = query.lowercase(Locale.ROOT)
        when {
            lower.contains("whatsapp") || lower.contains("واٹس ایپ") -> {
                speakText("واٹس ایپ کھول رہی ہوں", "ur")
                AppIntentDispatcher.openWhatsApp(this)
            }
            lower.contains("youtube") || lower.contains("یوٹیوب") -> {
                speakText("Opening YouTube", "en")
                AppIntentDispatcher.openYouTube(this)
            }
            lower.contains("tiktok") || lower.contains("ٹک ٹاک") -> {
                speakText("Opening TikTok and ready to scroll", "en")
                AppIntentDispatcher.openTikTok(this)
            }
            lower.contains("instagram") || lower.contains("انسٹاگرام") -> {
                speakText("Opening Instagram", "en")
                AppIntentDispatcher.openInstagram(this)
            }
            lower.contains("scroll") || lower.contains("اسکرول") -> {
                MarwaAccessibilityService.instance?.performScroll(
                    MarwaAccessibilityService.ScrollDirection.DOWN
                )
            }
            else -> {
                speakText("جی، میں نے سن لیا: $query", "ur")
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            textToSpeech?.language = Locale("ur", "PK")
        }
    }

    private fun speakText(text: String, lang: String = "ur") {
        if (!isTtsReady) return
        val locale = when (lang) {
            "ur" -> Locale("ur", "PK")
            "hi" -> Locale("hi", "IN")
            else -> Locale.US
        }
        textToSpeech?.language = locale
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "marwa_tts")
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any {
            it.id.contains(packageName) || it.resolveInfo.serviceInfo.packageName == packageName
        }
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}

@Composable
fun AssistantScreen(
    isAccessibilityEnabled: Boolean,
    onOpenAccessibilitySettings: () -> Unit,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSpeak: (String, String) -> Unit
) {
    var isListening by remember { mutableStateOf(false) }
    var userQuery by remember { mutableStateOf("") }
    var assistantResponse by remember { mutableStateOf("السلام علیکم! میں مروہ ہوں، آپ کا جیمینائی وائس اسسٹنٹ۔") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Bar & Accessibility Warning
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Marwa AI",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Gemini 3.8 Voice OS (مروہ)",
                        fontSize = 12.sp,
                        color = Color(0xFF10B981)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isAccessibilityEnabled) Color(0xFF065F46) else Color(0xFF991B1B)
                ) {
                    Text(
                        text = if (isAccessibilityEnabled) "SERVICE ACTIVE" else "PERMISSION NEEDED",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            if (!isAccessibilityEnabled) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2937)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Enable Accessibility to allow hands-free scrolling and clicking.",
                            fontSize = 11.sp,
                            color = Color(0xFFD1D5DB),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = onOpenAccessibilitySettings,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Text("Enable", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Center Voice Sphere & Responses
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            // Orb Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                if (isListening) Color(0xFF059669) else Color(0xFF3B82F6),
                                Color(0xFF0F172A)
                            )
                        )
                    )
                    .clickable {
                        isListening = !isListening
                        if (isListening) onStartListening() else onStopListening()
                    }
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                    contentDescription = "Microphone",
                    tint = Color.White,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = if (isListening) "Listening in Urdu / English / Hindi..." else "Tap to speak to Marwa",
                fontSize = 13.sp,
                color = Color(0xFF9CA3AF)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Marwa Output:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = assistantResponse,
                        fontSize = 14.sp,
                        color = Color.White,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Quick App Trigger Chips
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Hands-Free Voice Capabilities:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF6B7280)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = { onSpeak("واٹس ایپ پر میسج بھیجا جا رہا ہے", "ur") },
                    label = { Text("💬 WhatsApp", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = { onSpeak("Searching YouTube for AI news", "en") },
                    label = { Text("▶️ YouTube", fontSize = 11.sp) }
                )
                AssistChip(
                    onClick = { onSpeak("Scrolling TikTok feed", "en") },
                    label = { Text("⚡ TikTok", fontSize = 11.sp) }
                )
            }
        }
    }
}
