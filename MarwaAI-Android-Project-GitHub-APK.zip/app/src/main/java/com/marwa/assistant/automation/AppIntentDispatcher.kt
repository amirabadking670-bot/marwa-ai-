package com.marwa.assistant.automation

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log

object AppIntentDispatcher {

    fun openWhatsApp(context: Context, initialMessage: String = "") {
        try {
            val encodedMsg = Uri.encode(initialMessage)
            val uri = Uri.parse("https://api.whatsapp.com/send?text=$encodedMsg")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
            launchIntent?.let {
                it.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(it)
            }
        }
    }

    fun openYouTube(context: Context, query: String = "") {
        if (query.isNotEmpty()) {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } else {
            val launch = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            launch.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(launch)
        }
    }

    fun openTikTok(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
            ?: context.packageManager.getLaunchIntentForPackage("com.ss.android.ugc.trill")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com"))
        launch.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(launch)
    }

    fun openInstagram(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
        launch.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(launch)
    }

    fun openFacebook(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage("com.facebook.katana")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com"))
        launch.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(launch)
    }
}
