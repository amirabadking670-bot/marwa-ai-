package com.marwa.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald80 = Color(0xFFA7F3D0)
val EmeraldGrey80 = Color(0xFFD1D5DB)
val Cyan80 = Color(0xFF67E8F9)

val Emerald40 = Color(0xFF059669)
val EmeraldGrey40 = Color(0xFF4B5563)
val Cyan40 = Color(0xFF0891B2)

val DarkBackground = Color(0xFF0B0F17)
val DarkSurface = Color(0xFF131A26)
