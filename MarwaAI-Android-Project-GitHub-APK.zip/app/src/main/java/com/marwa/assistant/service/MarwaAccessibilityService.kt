package com.marwa.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*

class MarwaAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val TAG = "MarwaAccessibility"
        var instance: MarwaAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Marwa Accessibility Service initialized and connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observes active window changes for contextual assistant routing
    }

    override fun onInterrupt() {
        Log.w(TAG, "Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        serviceScope.cancel()
    }

    /**
     * Dispatches natural touch scroll gestures for TikTok, YouTube Shorts, Reels, and Facebook feeds.
     */
    fun performScroll(direction: ScrollDirection, callback: ((Boolean) -> Unit)? = null) {
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels

        val startX = (width / 2).toFloat()
        val startY = when (direction) {
            ScrollDirection.DOWN -> (height * 0.75f)
            ScrollDirection.UP -> (height * 0.25f)
        }
        val endY = when (direction) {
            ScrollDirection.DOWN -> (height * 0.25f)
            ScrollDirection.UP -> (height * 0.75f)
        }

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                callback?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Types voice-composed text into active EditText in WhatsApp, YouTube, TikTok or Instagram
     */
    fun enterTextAndSend(targetText: String, sendImmediately: Boolean = true): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val editTexts = mutableListOf<AccessibilityNodeInfo>()
        findNodesByClassName(rootNode, "android.widget.EditText", editTexts)

        if (editTexts.isEmpty()) return false
        val targetField = editTexts.lastOrNull() ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetText)
        }
        val textSet = targetField.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        if (textSet && sendImmediately) {
            serviceScope.launch {
                delay(250)
                clickSendButton()
            }
        }
        return textSet
    }

    fun clickSendButton(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val keywords = listOf("send", "post", "comment", "submit", "ارسال", "بھیجیں", "پوسٹ")

        for (kw in keywords) {
            val nodes = rootNode.findAccessibilityNodeInfosByText(kw)
            for (node in nodes) {
                if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                var p = node.parent
                while (p != null) {
                    if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    p = p.parent
                }
            }
        }
        return false
    }

    private fun findNodesByClassName(node: AccessibilityNodeInfo, targetClass: String, list: MutableList<AccessibilityNodeInfo>) {
        if (node.className?.toString() == targetClass) {
            list.add(node)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findNodesByClassName(it, targetClass, list) }
        }
    }

    enum class ScrollDirection { UP, DOWN }
}
