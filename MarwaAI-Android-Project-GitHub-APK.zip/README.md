# Marwa AI - Complete Native Android Voice Assistant (SDK 35)

Powered by Google Gemini 3.8 Flash, Android Accessibility Services, and Jetpack Compose.
Fully buildable and ready to import into Android Studio.

---

## 🚀 Quick Start: Build Debug APK in 2 Minutes

### 1. Requirements
- **Android Studio**: Ladybug (2024.2+), Koala, Iguana, or newer.
- **JDK**: Java 17 or Java 21 (bundled in Android Studio).
- **Target Device / Emulator**: Android 8.0 (API 26) through Android 15 (API 35).

### 2. Build via Command Line
Run inside the extracted folder:
```bash
# On Linux / macOS:
chmod +x gradlew
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```

The compiled debug APK will be created at:
```
app/build/outputs/apk/debug/app-debug.apk
```

### 3. Install on Your Phone via ADB
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 📱 Granting Required Android Permissions

Marwa AI uses authorized Android Accessibility and Voice APIs to control WhatsApp, YouTube, TikTok, Instagram, and Facebook hands-free.

### Option A: From Phone Settings UI
1. **Accessibility Service**:
   - Open Phone **Settings** -> **Accessibility** (or Additional Settings -> Accessibility).
   - Find **"Marwa AI"** (or "Marwa Voice Assistant Accessibility Service") under Downloaded Apps.
   - Toggle **ON** and accept the system accessibility prompt.
2. **Default Digital Assistant**:
   - Open Phone **Settings** -> **Apps** -> **Default Apps** -> **Digital Assistant app**.
   - Select **Marwa AI** as the default assistant.
3. **Microphone**:
   - Open Marwa AI app and tap the glowing voice orb. Accept microphone permission.

### Option B: Fast Setup via ADB (for Developers)
```bash
# Grant Audio recording permission:
adb shell pm grant com.marwa.assistant android.permission.RECORD_AUDIO

# Enable Accessibility Service instantly:
adb shell settings put secure enabled_accessibility_services com.marwa.assistant/com.marwa.assistant.service.MarwaAccessibilityService
adb shell settings put secure accessibility_enabled 1
```

---

## 📂 Project Architecture

```
MarwaAI/
├── settings.gradle.kts                   # Repository & module config
├── build.gradle.kts                      # Root Gradle build script
├── gradle.properties                     # AndroidX & JVM optimization flags
├── gradlew & gradlew.bat                 # Gradle wrapper executable scripts
├── gradle/
│   ├── libs.versions.toml                # Standard Gradle Version Catalog
│   └── wrapper/
│       └── gradle-wrapper.properties     # Gradle 8.11.1 distribution
└── app/
    ├── build.gradle.kts                  # App dependencies (Compose, OkHttp, Coroutines)
    ├── proguard-rules.pro                # Proguard preservation rules
    └── src/main/
        ├── AndroidManifest.xml           # Service declarations & permissions
        ├── java/com/marwa/assistant/
        │   ├── MainActivity.kt           # Compose Voice UI & Speech Engine
        │   ├── service/
        │   │   ├── MarwaAccessibilityService.kt   # Gestures, scroll flicks & node actions
        │   │   ├── MarwaVoiceInteractionService.kt # System voice assistant engine
        │   │   └── MarwaOverlayService.kt         # Floating mic bubble foreground service
        │   ├── automation/
        │   │   └── AppIntentDispatcher.kt         # WhatsApp, YouTube, TikTok intent routing
        │   ├── network/
        │   │   └── GeminiClient.kt                # Gemini 3.8 Flash model REST client
        │   └── ui/theme/
        │       ├── Color.kt
        │       ├── Theme.kt
        │       └── Type.kt
        └── res/
            ├── values/
            │   ├── strings.xml           # Accessibility descriptions (Urdu/English)
            │   ├── colors.xml            # Emerald & dark theme palette
            │   └── themes.xml            # Material3 NoActionBar theme
            ├── xml/
            │   ├── accessibility_service_config.xml # Touch exploration & gesture flags
            │   └── voice_interaction_service.xml    # Assistant session metadata
            ├── drawable/
            │   └── ic_launcher_foreground.xml       # Adaptive icon vector
            └── mipmap-anydpi-v26/
                ├── ic_launcher.xml
                └── ic_launcher_round.xml
```

---

## 🛡️ Privacy & Compliance
- **Zero Device Root**: Completely compliant with Google Play Accessibility Services Policy.
- **Ephemerality**: Audio and screen node queries are processed locally and through ephemeral Gemini 3.8 Flash calls without persistent telemetry.
